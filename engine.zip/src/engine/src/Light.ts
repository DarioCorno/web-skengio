// src/engine/Light.ts
import { vec3, mat4 } from 'gl-matrix';

export class Light {
  public position: vec3;
  public color: vec3;

  constructor(position: vec3 = vec3.fromValues(0, 3, 3), color: vec3 = vec3.fromValues(1, 1, 1)) {
    this.position = position;
    this.color = color;
  }

  /**
   * Sends the light data to the WebGL shader.
   */
  apply(gl: WebGL2RenderingContext, program: WebGLProgram) {
    const uLightPosition = gl.getUniformLocation(program, 'uLightPosition');
    const uLightColor = gl.getUniformLocation(program, 'uLightColor');

    gl.uniform3fv(uLightPosition, this.position);
    gl.uniform3fv(uLightColor, this.color);
  }


  getModelMatrix(): mat4 {
    const model = mat4.create();
    mat4.translate(model, model, [this.position[0], this.position[1], this.position[2]]);
    return model;
  }

  debugInfo(): void {
    console.log("Light Debug Info:");
    console.log("Position:", this.position);
    console.log("Color:", this.color);
  }  
}
