// src/engine/Mesh.ts
import { mat4, vec3 } from 'gl-matrix';
import * as ENGINE from '../ENGINE';

// Note: The Material type will be re‑exported in ENGINE; here we refer to it as ENGINE.Material.
export interface MeshOptions {
  positions: Float32Array;
  normals: Float32Array;
  indices: Uint16Array;
  uv?: Float32Array;
}

export class Mesh {
  private isDirty: boolean = true;
  // Transform properties
  public position = vec3.create();
  public rotation = vec3.create();
  public scale = vec3.fromValues(1, 1, 1);

  // Vertex data
  private positions: Float32Array;
  private normals: Float32Array;
  private indices: Uint16Array;
  private uv?: Float32Array;

  // WebGL buffers
  public positionsBuffer: WebGLBuffer | null = null;
  public normalBuffer: WebGLBuffer | null = null;
  public uvBuffer: WebGLBuffer | null = null;
  public uv2Buffer: WebGLBuffer | null = null;
  public indexBuffer: WebGLBuffer | null = null;

  public vertexCount: number;
  public indexCount: number;
  public hasUV: boolean;

  // Material (if assigned) – using ENGINE.Material type.
  public material: ENGINE.Materials.MaterialTexture | null = null;

  private uniformLocationsSet: boolean = false;
  private uniforms = {
    aPositionLocation: -1,
    aNormalLocation: -1,
    aUVLocation: -1,
    aObjectIDLocation: -1
  }

  constructor(options: MeshOptions) {
    const { positions, normals, indices, uv } = options;
    this.positions = positions;
    this.normals = normals;
    this.indices = indices;
    this.uv = uv;

    this.vertexCount = positions.length / 3;
    this.indexCount = indices.length;

    this.hasUV = !!uv;

  }

  setDirty(): void {
    this.isDirty = true;
  }

  clearDirty(): void {
    this.isDirty = false;
  }

  getDirty(): boolean {
    return this.isDirty;
  }

  init(gl: WebGL2RenderingContext): void {
    // Create and fill position buffer
    this.positionsBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.positionsBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, this.positions, gl.STATIC_DRAW);
    gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(0);

    // Create and fill normal buffer
    this.normalBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.normalBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, this.normals, gl.STATIC_DRAW);
    gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(1);

    // Optional UV buffers
    if (this.uv) {
      this.uvBuffer = gl.createBuffer();
      gl.bindBuffer(gl.ARRAY_BUFFER, this.uvBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, this.uv, gl.STATIC_DRAW);
      gl.vertexAttribPointer(2, 2, gl.FLOAT, false, 0, 0);
      gl.enableVertexAttribArray(2);      
    }

    // Create and fill index buffer
    this.indexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.indices, gl.STATIC_DRAW);
  }

  /**
   * Computes and returns the model matrix for this mesh using its position, rotation, and scale.
   */
  getModelMatrix(): mat4 {
    const model = mat4.create();
    mat4.translate(model, model, [this.position[0], this.position[1], this.position[2]]);
    mat4.rotateX(model, model, this.rotation[0]);
    mat4.rotateY(model, model, this.rotation[1]);
    mat4.rotateZ(model, model, this.rotation[2]);
    mat4.scale(model, model, [this.scale[0], this.scale[1], this.scale[2]]);
    return model;
  }

  //given a shaderPrograms finds the uniforms needed to render this mesh
  setForwardUniformsLocations(gl: WebGL2RenderingContext, program: WebGLProgram) {
    if(this.uniformLocationsSet) return;

    this.uniforms.aPositionLocation = gl.getAttribLocation(program, 'aPosition');
    this.uniforms.aNormalLocation   = gl.getAttribLocation(program, 'aNormal');
    this.uniforms.aUVLocation       = gl.getAttribLocation(program, 'aUV'); 
    this.uniforms.aObjectIDLocation = gl.getAttribLocation(program, 'uObjectID'); 
    
    this.uniformLocationsSet = true;
  }

  assignFwdBuffersToUniforms(gl: WebGL2RenderingContext, objIndex: number) {
      // Bind and enable position buffer.
      gl.bindBuffer(gl.ARRAY_BUFFER, this.positionsBuffer);
      gl.enableVertexAttribArray(this.uniforms.aPositionLocation);
      gl.vertexAttribPointer(this.uniforms.aPositionLocation, 3, gl.FLOAT, false, 0, 0);

      // Bind and enable normal buffer.
      gl.bindBuffer(gl.ARRAY_BUFFER, this.normalBuffer);
      gl.enableVertexAttribArray(this.uniforms.aNormalLocation);
      gl.vertexAttribPointer(this.uniforms.aNormalLocation, 3, gl.FLOAT, false, 0, 0);

      // Bind optional UV buffer.
      if (this.uvBuffer) {
        gl.bindBuffer(gl.ARRAY_BUFFER, this.uvBuffer);
        gl.enableVertexAttribArray(this.uniforms.aUVLocation);
        gl.vertexAttribPointer(this.uniforms.aUVLocation, 2, gl.FLOAT, false, 0, 0);
      }

      if(this.uniforms.aObjectIDLocation > -1) {
        gl.uniform1f(this.uniforms.aObjectIDLocation, objIndex);
      }

  }

  draw(gl: WebGL2RenderingContext) {
      // Bind the index buffer and draw the mesh using indexed rendering.
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.indexBuffer);
      gl.drawElements(gl.TRIANGLES, this.indexCount, gl.UNSIGNED_SHORT, 0);
  }

  debugInfo(): void {
    console.log("Mesh Debug Info:");
    console.log("Position:", this.position);
    console.log("Rotation:", this.rotation);
    console.log("Scale:", this.scale);
    console.log(`Vertex Count: ${this.vertexCount}, Index Count: ${this.indexCount}`);
    console.log("Dirty:", this.getDirty());
    if (this.material) {
      console.log("Material Debug Info:");
      this.material.debugInfo();
    }
  }  
}
