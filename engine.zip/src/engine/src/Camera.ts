// src/engine/Camera.ts
import { mat4, vec3 } from 'gl-matrix';

export class Camera {
  // Transform fields
  public position = vec3.fromValues(0.0, 0.0, 5.0 );
  public rotation = vec3.fromValues( 0, 0, 0 );

  // Typically scale is not used on cameras, but included for completeness
  public scale = vec3.fromValues(1,1,1);

  // Projection settings
  public fieldOfView: number; // in degrees
  public aspect: number;
  public near: number;
  public far: number;

  constructor(fieldOfView = 45, aspect = 1, near = 0.1, far = 100) {
    this.fieldOfView = fieldOfView;
    this.aspect = aspect;
    this.near = near;
    this.far = far;
  }

  getProjectionMatrix(): mat4 {
    const out = mat4.create();
    // Convert FOV to radians
    const fovRad = (this.fieldOfView * Math.PI) / 180;
    mat4.perspective(out, fovRad, this.aspect, this.near, this.far);
    return out;
  }

  getViewMatrix(): mat4 {
    // Build a transform from position/rotation, then invert
    const transform = mat4.create();

    // Translate
    mat4.translate(transform, transform, [
      this.position[0], 
      this.position[1], 
      this.position[2]
    ]);

    // Rotate X, Y, Z
    mat4.rotateX(transform, transform, this.rotation[0]);
    mat4.rotateY(transform, transform, this.rotation[1]);
    mat4.rotateZ(transform, transform, this.rotation[2]);

    // If scaling was used (rare for cameras):
    mat4.scale(transform, transform, [this.scale[0], this.scale[1], this.scale[2]]);

    // Invert to get the camera's view matrix
    const view = mat4.create();
    mat4.invert(view, transform);

    return view;
  }

  handleResize(width: number, height: number) {
    this.aspect = width / height;
  }

  debugInfo(): void {
    console.log("Camera Debug Info:");
    console.log("Position:", this.position);
    console.log("Rotation:", this.rotation);
    console.log("Scale:", this.scale);
    console.log(`FOV: ${this.fieldOfView}, Aspect: ${this.aspect}, Near: ${this.near}, Far: ${this.far}`);
  }  
}
