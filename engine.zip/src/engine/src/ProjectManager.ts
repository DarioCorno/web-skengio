import * as ENGINE from '../ENGINE';

export class ProjectData {
    private projectSource: any | null = null;
    constructor() {

    }
}

export class ProjectManager {
    private projectData: ProjectData | null = null;

    constructor() {

    }
}