import vertexShaderSource from '../shaders/deferredVertexShader.glsl?raw';
import fragmentShaderSource from '../shaders/deferredFragmentShader.glsl?raw';
import * as ENGINE from '../ENGINE'
import { mat4 } from 'gl-matrix';

export class GBufferDebugger {
    private gl: WebGL2RenderingContext;
    private program: WebGLProgram;
    private vao: WebGLVertexArrayObject | null;
  
    public debugMode : number = 0;  //0 = final render, 1 = position, 2 = normal and so on

    constructor(gl: WebGL2RenderingContext) {
      this.gl = gl;
  
      // Initialize the shader program
      this.program = this.createShaderProgram();
  
      // Initialize the quad VAO
      this.vao = this.createQuadVAO();
    }
  
    private createShaderProgram(): WebGLProgram {

      const vertexShader = this.compileShader(this.gl.VERTEX_SHADER, vertexShaderSource);
      const fragmentShader = this.compileShader(this.gl.FRAGMENT_SHADER, fragmentShaderSource);
  
      const program = this.gl.createProgram();
      if (!program) {
        throw new Error("Failed to create shader program.");
      }
  
      this.gl.attachShader(program, vertexShader);
      this.gl.attachShader(program, fragmentShader);
      this.gl.linkProgram(program);
  
      if (!this.gl.getProgramParameter(program, this.gl.LINK_STATUS)) {
        const log = this.gl.getProgramInfoLog(program);
        this.gl.deleteProgram(program);
        throw new Error(`Failed to link shader program: ${log}`);
      }
  
      // Clean up shaders after linking
      this.gl.deleteShader(vertexShader);
      this.gl.deleteShader(fragmentShader);
  
      return program;
    }
  
    private compileShader(type: GLenum, source: string): WebGLShader {
      const shader = this.gl.createShader(type);
      if (!shader) {
        throw new Error(`Failed to create shader of type ${type}.`);
      }
  
      this.gl.shaderSource(shader, source);
      this.gl.compileShader(shader);
  
      if (!this.gl.getShaderParameter(shader, this.gl.COMPILE_STATUS)) {
        const log = this.gl.getShaderInfoLog(shader);
        this.gl.deleteShader(shader);
        throw new Error(`Failed to compile shader: ${log}`);
      }
  
      return shader;
    }
  
    private createQuadVAO(): WebGLVertexArrayObject | null {
      const gl = this.gl;
  
      // Quad vertices (position and UV coordinates)
      const vertices = new Float32Array([
        // Position   // UV
        -1.0, -1.0,  0.0, 0.0,
         1.0, -1.0,  1.0, 0.0,
        -1.0,  1.0,  0.0, 1.0,
         1.0,  1.0,  1.0, 1.0,
      ]);
  
      const vao = gl.createVertexArray();
      const vbo = gl.createBuffer();
  
      gl.bindVertexArray(vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
      gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
  
      // Enable position attribute (location 0)
      gl.enableVertexAttribArray(0);
      gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 4 * Float32Array.BYTES_PER_ELEMENT, 0);
  
      // Enable UV attribute (location 1)
      gl.enableVertexAttribArray(1);
      gl.vertexAttribPointer(1, 2, gl.FLOAT, false, 4 * Float32Array.BYTES_PER_ELEMENT, 2 * Float32Array.BYTES_PER_ELEMENT);
  
      // Unbind VAO and VBO
      gl.bindVertexArray(null);
      gl.bindBuffer(gl.ARRAY_BUFFER, null);
  
      return vao;
    }
  
    public render(textures: { [key: string]: WebGLTexture }, scene: ENGINE.Scene): void {
        const gl = this.gl;
    
        // Use the shader program
        gl.useProgram(this.program);
    
        // Bind the quad VAO
        gl.bindVertexArray(this.vao);
    
        // Bind the texture to texture unit 0
        gl.activeTexture(gl.TEXTURE0);
        gl.bindTexture(gl.TEXTURE_2D, textures['position']);  
        // Set the sampler uniform to texture unit 0
        const textureLocation0 = gl.getUniformLocation(this.program, "uPosition");
        gl.uniform1i(textureLocation0, 0);

        // Bind the texture to texture unit 0
        gl.activeTexture(gl.TEXTURE1);
        gl.bindTexture(gl.TEXTURE_2D, textures['albedo']);  
        // Set the sampler uniform to texture unit 0
        const textureLocation1 = gl.getUniformLocation(this.program, "uAlbedo");
        gl.uniform1i(textureLocation1, 1);
    
        // Bind the texture to texture unit 0
        gl.activeTexture(gl.TEXTURE2);
        gl.bindTexture(gl.TEXTURE_2D, textures['normal']);  
        // Set the sampler uniform to texture unit 0
        const textureLocation2 = gl.getUniformLocation(this.program, "uNormal");
        gl.uniform1i(textureLocation2, 2);

        /*
        // Bind the texture to texture unit 3
        gl.activeTexture(gl.TEXTURE3);
        gl.bindTexture(gl.TEXTURE_2D, textures['uv']);  
        // Set the sampler uniform to texture unit 0
        const textureLocation3 = gl.getUniformLocation(this.program, "uUV");
        gl.uniform1i(textureLocation3, 3);
        */

        // Bind the texture to texture unit 3
        gl.activeTexture(gl.TEXTURE3);
        gl.bindTexture(gl.TEXTURE_2D, textures['objid']);  
        // Set the sampler uniform to texture unit 0
        const textureLocation3 = gl.getUniformLocation(this.program, "uObjectID");
        gl.uniform1i(textureLocation3, 3);

        //bind the lights
        const lights = scene.getLights();    
        const lightPosLocation = gl.getUniformLocation(this.program, "uLightPosition");
        gl.uniform3fv(lightPosLocation, lights[0].position);     
        const lightColorLocation = gl.getUniformLocation(this.program, "uLightColor");
        gl.uniform3fv(lightColorLocation,  lights[0].color);     

        //set the debugging mode
        gl.uniform1i(gl.getUniformLocation(this.program,'uDebugMode'), this.debugMode);

        // Draw the quad
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    
        // Unbind VAO
        gl.bindVertexArray(null);
    }
  }
  