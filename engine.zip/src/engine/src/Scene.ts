// src/engine/Scene.ts
import * as ENGINE from '../ENGINE';

export class Scene {
  private meshes: ENGINE.Mesh[] = [];
  private lights: ENGINE.Light[] = [];
  private camera: ENGINE.Camera;

  constructor(camera: ENGINE.Camera) {
    this.camera = camera;
  }

  addMesh(mesh: ENGINE.Mesh): void {
    this.meshes.push(mesh);
  }

  addLight(light: ENGINE.Light): void {
    this.lights.push(light);
  }

  getMeshes(): ENGINE.Mesh[] {
    return this.meshes;
  }

  getLights(): ENGINE.Light[] {
    return this.lights;
  }

  getCamera(): ENGINE.Camera {
    return this.camera;
  }

  debugInfo(): void {
    console.log("Scene Debug Info:");
    console.log(`Meshes count: ${this.meshes.length}`);
    console.log(`Lights count: ${this.lights.length}`);
    console.log("Camera:");
    this.camera.debugInfo();
    for (let i = 0; i < this.meshes.length; i++) {
      console.log(`Mesh ${i} Debug Info:`);
      this.meshes[i].debugInfo();
    }
    for (let i = 0; i < this.lights.length; i++) {
      console.log(`Light ${i} Debug Info:`);
      this.lights[i].debugInfo();
    }
  }  
}
