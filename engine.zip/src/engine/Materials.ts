import { MaterialColor } from './src/Material'
import { MaterialTexture } from './src/Material'

export {
    MaterialColor,
    MaterialTexture
}