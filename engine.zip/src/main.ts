// src/main.ts
import * as ENGINE from './engine/ENGINE';
import { vec3, vec4 } from 'gl-matrix';
import { BitmapFontAtlas } from './engine/utils/BitmapFontAtlas.js';

async function main() {
  console.log('Initializing scene...');

  // Create camera, scene, and light.
  const camera = new ENGINE.Camera(45, window.innerWidth / window.innerHeight, 0.1, 100);
  camera.position[2] = 5;
  const scene = new ENGINE.Scene(camera);
  
  const light = new ENGINE.Light(vec3.fromValues(5,0,5), vec3.fromValues(0.5, 0.5, 0.5));
  light.position[0] = 10;
  light.position[1] = 0;
  light.position[2] = 0;
  scene.addLight(light);

  // Create and initialize WindowManager (which creates a renderer).
  const wm = new ENGINE.WindowManager('my-canvas', { 
    enableGUI: true,
    showDebug: true
  });
  if(!wm.gl) throw new Error('Unable to initialize WebGL2');

  await wm.init();
  console.log('Engine initialized.');

  const bfa = new BitmapFontAtlas('test', 'Arial', '#fff', '#000', 512, true);

  // Create a cube mesh using your GeometryGenerator (assume it returns a MeshOptions object).
  const torusData = ENGINE.Utils.GeometryGenerator.generateTorus(0.6,0.3,32,16); // .generateSphere(1.1, 16, 16); // generateCube();
  const torusMesh = new ENGINE.Mesh(torusData);
  torusMesh.position[0] = -1.8;
  scene.addMesh(torusMesh);

  const cubeData = ENGINE.Utils.GeometryGenerator.generateCube();
  const cubeMesh = new ENGINE.Mesh(cubeData);
  cubeMesh.position[0] = 1.8;
  scene.addMesh(cubeMesh);

  const textData = ENGINE.Utils.GeometryGenerator.GenerateTextMesh('Prova!' , bfa, 0, 0);
  const textMesh = new ENGINE.Mesh(textData);
  textMesh.position[0] = 0.0;
  textMesh.scale[0] = 0.7;
  textMesh.scale[1] = 0.7;
  textMesh.scale[2] = 0.7;
  scene.addMesh(textMesh);

  if (wm.renderer && (wm.renderer as any).gl) {
    const gl = (wm.renderer as any).gl as WebGL2RenderingContext;
    cubeMesh.init(gl);
    torusMesh.init(gl);
    textMesh.init(gl);
  }
  console.log('Mesh added to scene.');

  // Set an initial rotation.
  cubeMesh.rotation[1] = Math.PI / 4;

  const textureLoader = new ENGINE.Utils.TextureLoader(wm.gl);
  const webglLogoTexture = await textureLoader.loadTexture('/img/test_checker.png');
  const uvRefTexture = await textureLoader.loadTexture('/img/uv_ref.png');
  const fontTexture = await textureLoader.createColoredTransparentTextureFromCanvas('test',255,0,0); // createTextureFromCanvas('test');

  //const material = new ENGINE.Materials.MaterialColor(vec4.fromValues(1,0,1,1));
  cubeMesh.material = new ENGINE.Materials.MaterialTexture();
  cubeMesh.material.setTexture("diffuse", webglLogoTexture);

  torusMesh.material = new ENGINE.Materials.MaterialTexture();
  torusMesh.material.setTexture("diffuse", uvRefTexture);

  textMesh.material = new ENGINE.Materials.MaterialTexture();
  textMesh.material.setTexture('diffuse', fontTexture);
  textMesh.material.isTransparent = true;

  // Animate: Render the scene 4 times with different offsets.
  let lastTime = performance.now();

  window.addEventListener('resize', (ev) => {
    handleResize();
  });

  function handleResize() {
    // Get the new dimensions
    const winWidth = window.innerWidth;
    const winHeight = window.innerHeight;
    
    // Get the device pixel ratio for high-DPI screens
    const dpr = window.devicePixelRatio || 1;    
    const width = winWidth * dpr;
    const height = winHeight * dpr;
    wm.handleResize(width, height);
    camera.handleResize(width, height);
  }  

  function animate(currentTime: number) {
    wm.startFPS();

    requestAnimationFrame(animate);
    const deltaTime = currentTime - lastTime;
    lastTime = currentTime;

    // Update cube rotation.
    cubeMesh.rotation[0] += 0.002;
    cubeMesh.rotation[1] += 0.01;
    cubeMesh.rotation[2] += 0.005;

    torusMesh.rotation[0] -= 0.002;
    torusMesh.rotation[1] += 0.02;
    torusMesh.rotation[2] += 0.003;

    textMesh.rotation[1] += 0.005;
    textMesh.position[3] = -5.0;

    torusMesh.position[0] = -1.8 + Math.sin(currentTime / 800.0);
    
    // Render the scene to this framebuffer.
    wm.renderer!.render(scene);

    wm.endFPS();
  }

  let loading = document.getElementById('loading-screen');
  if(loading) {
    loading.style.display = 'none';
  }
  handleResize();
  requestAnimationFrame(animate);
}

main().catch(err => console.error('Error in main loop:', err));
